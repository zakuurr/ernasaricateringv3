<div>
   <div class="container" style="padding: 30px 0">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                Profil Saya
            </div>
            <div class="panel-body">
                <div class="row">
                <div class="col-md-4">
                        <?php if($user->foto): ?>
                        <img src="<?php echo e(asset('storage/fotouser/'. Auth::user()->foto)); ?>" width="100%">
                        <?php else: ?>
                       Tidak Ada Foto
                        <?php endif; ?>
                </div>
                <div class="col-md-8">
                       <p class="text-black">Nama : <?php echo e($user->name); ?></p>
                       <p class="text-black">Alamat : <?php echo e($user->alamat); ?></p>
                       <p class="text-black">No Handphone : <?php echo e($user->nohp); ?></p>
                       <p class="text-black">Email : <?php echo e($user->email); ?></p>
                       <a href="<?php echo e(route('editprofile')); ?>" class="btn btn-info"> Ubah</a>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php /**PATH D:\ernasaricateringv3\resources\views/livewire/user-profile-component.blade.php ENDPATH**/ ?>