<div>
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="text-black text-center">Detail Pesanan</h5>
                </div>


          <!-- Main content -->
          <div class="invoice p-3 mb-3">
            <!-- info row -->
            <div class="row invoice-info">
                <table class="table table">
                      <tr>
                        <td width="20%">ID Pesanan</td>
                        <td><?php echo e($pesanan->id); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Nama Pelanggan</td>
                        <td><?php echo e($pesanan->nama_lengkap); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Tanggal Pemesanan</td>
                        <td><?php echo e($pesanan->created_at); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">No. Hp</td>
                        <td><?php echo e($pesanan->nohp); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Alamat</td>
                        <td><?php echo e($pesanan->alamat); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Metode Pembayaran</td>
                        <td><?php echo e($pesanan->transaction->mode); ?></td>
                      </tr>

                      <tr>
                        <td width="20%">Catatan Pesanan</td>
                        <td><?php echo e($pesanan->catatan); ?></td>
                      </tr>

                  </table>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- Table row -->
            <div class="row">
              <div class="col-12 table-responsive">
                <table class="table table-striped">
                  <thead>
                  <tr>
                    <th width="10%">Kuantitas</th>
                    <th width="20%">Foto</th>
                    <th>Menu Makanan</th>
                    <th>Harga</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $pesanan->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><img src="<?php echo e(asset('storage/fotomenu/'. $item->menu->foto)); ?>" width="50%" ></td>
                        <td><?php echo e($item->menu->nama_menu); ?></td>
                        <td>Rp. <?php echo e(number_format($item->price,0,'.','.')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>
                </table>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <div class="row">
              <!-- accepted payments column -->
              
              <!-- /.col -->
              
              <div class="col-12">
                <div class="table-responsive">
                  <table class="table">
                    <tr>
                      <th style="width:72%">Subtotal</th>
                      <td>Rp. <?php echo e(number_format((float)$pesanan->subtotal,3,'.','.')); ?></td>
                    </tr>
                    <tr>
                      <th>Ongkir</th>
                      <td>Rp. 10.000</td>
                    </tr>
                    <tr>
                      <th>Total:</th>
                      <td><b> Rp. <?php echo e(number_format((float)$pesanan->total,0,'.','.')); ?></b></td>
                    </tr>
                    <tr>
                        <?php if($pesanan->status == 'dikirim'): ?>
                        <th>Tanggal kirim</th>
                        <td><b> <?php echo e($pesanan->delivered_date); ?></b></td>
                        <?php elseif($pesanan->status == 'cancel'): ?>
                        <th>Tanggal cancel</th>
                        <td><b> <?php echo e($pesanan->canceled_date); ?></b></td>
                        <?php endif; ?>
                    </tr>
                  </table>
                </div>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- this row will not appear when printing -->
            <div class="row no-print">
              <div class="col-12">

                

                

                
<?php if($pesanan->status == 'dipesan'): ?>
                     <a href="<?php echo e(route('orders')); ?>" style="margin: 5px;" wire:click.prevent="cancelOrder" class="tombol-cancel btn btn-danger float-right"><i class="far fa-back"></i> Cancel Order </a>
<?php endif; ?>
                <a href="<?php echo e(route('orders')); ?>" style="margin: 5px;" class="btn btn-warning float-right"><i class="far fa-back"></i> Kembali </a>
              </div>
            </div>
          </div>
        </div>
          <!-- /.invoice -->
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->

    <script>
    $('.tombol-cancel').on('click', function (e) {

        e.preventDefault();

        const href =$(this).attr('href');

        Swal.fire({
        title: 'Apakah anda yakin ?',
        text: "Transaksi pesanan ini akan dicancel",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya'
        }).then((result) => {
        if (result.value) {
            document.location.href = href;
            Swal.fire(
          'Berhasil!',
          'Pesanan berhasil dicancel.',
          'success'
        )
        }
        })

        });

        </script>
</div>
<?php /**PATH D:\ernasaricateringv3\resources\views/livewire/user-orders-details-component.blade.php ENDPATH**/ ?>