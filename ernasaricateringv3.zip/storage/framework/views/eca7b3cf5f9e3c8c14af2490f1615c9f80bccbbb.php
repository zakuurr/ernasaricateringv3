<div>
  <div style="padding: 30px 0" class="container">
    <div class="row">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Ubah Password
                        </div>
                        <div class="panel-body">
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(Session::get('error')); ?>

                            </div>
                        <?php endif; ?>
                            <form wire:submit.prevent="changePassword" class="form-horizontal">
                                <div class="form-group">
                                    <label for="" class="col-md-4 control-label">Password saat ini</label>
                                    <div class="col-md-4">
                                        <input type="password" placeholder="Password saat ini" class="form-control input-md" name="current_password" wire:model="current_password">

                                        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="" class="col-md-4 control-label">Password baru</label>
                                    <div class="col-md-4">
                                        <input type="password" placeholder="Password Baru" class="form-control input-md" name="password" wire:model="password">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="" class="col-md-4 control-label">Konfirmasi Password baru</label>
                                    <div class="col-md-4">
                                        <input type="password" placeholder="Konfirmasi Password baru" class="form-control input-md" name="password_confirmation" wire:model="password_confirmation">

                                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">

                                    <div class="col-md-4">
                                       <button type="submit" class="btn btn-primary">Submit </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </div>
  </div>
</div>
<?php /**PATH D:\ernasaricateringv3\resources\views/livewire/user-change-password-component.blade.php ENDPATH**/ ?>