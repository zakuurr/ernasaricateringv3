
<?php $__env->startSection('title'); ?>
    Laporan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<section class="content">
    <div class="container-fluid">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Laporan Penjualan</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form method="get" name="FormTambah" onsubmit="return Validation()" enctype="multipart/form-data"
            action="<?php echo e(route('laporan.show')); ?>">
             <?php echo csrf_field(); ?>
              <div class="card-body">
                <div class="form-group">
                    <label for="tgl1">Dari tanggal :</label>
                    <input type="date" class="form-control" required id="tgl1" name="tgl1" placeholder="Pilih Tanggal Awal">
                </div>
                <div class="form-group">
                    <label for="tgl2">Sampai Tanggal :</label>
                    <input type="date" class="form-control" required id="tgl2" name="tgl2" placeholder="Pilih Tanggal AKhir">
                </div>
                <div class="form-group">
                    <label for="jenis_laporan">Jenis Laporan :</label> <br>
                    <input type="radio" name="jenis_laporan" value="rpenjualan" id="jenis_laporan"> Rekap Penjualan <br>
                    <input type="radio" name="jenis_laporan" value="rpendapatan" id="jenis_laporan"> Rekap Pendapatan
                </div>
                <div class="form-group">
                    <button type="submit" id="search" class="btn btn-success"><i class="fa fa-search"></i> Cari data</button>
                </div>
            </form>
          </div>
          <!-- /.card -->

    </div><!-- /.container-fluid -->
  </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/layout-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ernasaricateringv3\resources\views/backend/laporan/index.blade.php ENDPATH**/ ?>