<div>
    <main id="main" class="main-site">

		<div class="container">
			<div class="main-content-area">
             <?php if(Cart::instance('cart')->count() > 0): ?>
				<div class="wrap-iten-in-cart">
                    <?php if(Session::has('success_message')): ?>
                    <div class="alert alert-success">
                        <strong>Success</strong> <?php echo e(Session::get('success_message')); ?>


                    </div>
                    <?php endif; ?>
                    
					<h3 class="box-title">Nama Menu</h3>
					<ul class="products-cart">
                        <?php $__currentLoopData = Cart::instance('cart')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="pr-cart-item">
							<div class="product-image">
								<figure><img src="<?php echo e(asset('storage/fotomenu/'. $item->model->foto)); ?>" alt="" class="img-fluid"></figure>
							</div>
							<div class="product-name">
								<a class="link-to-product" href="#"><?php echo e($item->model->nama_menu); ?></a>
							</div>
							<div class="price-field produtc-price"><p class="price">Rp. <?php echo e(number_format($item->model->harga,0,'.','.')); ?></p></div>
							<div class="quantity">
								<div class="quantity-input">
									<input type="number" name="product-quatity" value="<?php echo e($item->qty); ?>" pattern="[0-9]*" max="<?php echo e($item->model->stock); ?>">
									<a class="btn btn-increase" href="#" wire:click.prevent="increaseQuantity('<?php echo e($item->rowId); ?>')"></a>
									<a class="btn btn-reduce" href="#" wire:click.prevent="decreaseQuantity('<?php echo e($item->rowId); ?>')"></a>
								</div>
							</div>
							<div class="price-field sub-total"><p class="price">Rp. <?php echo e(number_format($item->subtotal,0,'.','.')); ?></p></div>
							<div class="delete">
								<a href="#" class="btn btn-delete" title="" wire:click.prevent="destroy('<?php echo e($item->rowId); ?>')">
									<span>Hapus</span>
									<i class="fa fa-times-circle" aria-hidden="true"></i>
								</a>
							</div>
						</li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
                    
				</div>

				<div class="summary">
					<div class="order-summary">
						<h4 class="title-box">RINGKASAN PESANAN</h4>
                        <label for="" class="summary-info inline-block mb-3 text-sm uppercase font-medium">Metode Pembayaran</label>
                        
                        <br>
                        
                        <p class="summary-info"><span class="title">Subtotal</span><b class="index">Rp. <?php echo e(Cart::instance('cart')->subtotal(0,'.','.')); ?></b></p>
                        
						
                        <p class="summary-info total-info "><span class="title">Total</span><b class="index">
                            
                            Rp. <?php echo e(Cart::instance('cart')->total(0,'.','.')); ?>

                            
                        </b></p>
					</div>
					<div class="checkout-info">
						<a class="btn btn-checkout text-black" wire:click.prevent="checkout" style="background-color: #d49701; :color : black">Check out</a>
						<a class="link-to-shop" href="<?php echo e(route('list-menu')); ?>">Lanjutkan Belanja<i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a>
					</div>
					<div class="update-clear">
						<a  wire:click.prevent="destroyAll()" class="btn btn-sm text-black" style="background-color: #d49701; :color : black">Kosongkan Keranjang</a>
						
					</div>
				</div>
            <?php else: ?>
            <div class="text-center" style="padding: 30px 0;">
                    <h1> Keranjang Kosong</h1>
            </div>
            <?php endif; ?>
			</div><!--end main content area-->
		</div><!--end container-->

	</main>
</div>
<?php /**PATH D:\ernasaricateringv3\resources\views/livewire/keranjang.blade.php ENDPATH**/ ?>