<div>
    <div class="card">
        <div class="card-header">
          <h2 class="text-center text-black">Pesanan Saya</h2>
        </div>
        <!-- /.card-header -->
        <?php if(Cart::instance('cart')->count() < 0): ?>
        <h1 class="text-center text-black">Tidak Ada Pesanan</h1>
         <?php else: ?>

        <div class="card-body">
          
          <table id="example1" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>No</th>
              <th>ID Pesanan</th>
              <th>Sub total</th>
              <th>Total</th>
              <th>Nama Lengkap</th>
              <th>Email</th>
              <th>No Hp</th>
              <th>Alamat</th>
              <th>Status</th>
              <th>Tanggal Pesanan</th>
              <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->subtotal); ?></td>
                <td><?php echo e($item->total); ?></td>
                <td><?php echo e($item->nama_lengkap); ?></td>
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->nohp); ?></td>
                <td><?php echo e($item->alamat); ?></td>
                <td><?php echo e($item->status); ?></td>
                <td><?php echo e($item->created_at); ?></td>
                
                <td>
                  <center>
                    <a class="btn btn-warning" href="<?php echo e(route('orders.detail', $item->id)); ?>" ><font color="white"><i class="fa fa-eye"></i> Lihat detail</font></a>

                    <?php if($item->status == 'sedang-dikirim'): ?>

                    <button wire:click="destroy(<?php echo e($item->id); ?>)" class="btn btn-sm btn-success"><font color="white"><i class="fa fa-check"></i> Pesanan Diterima</font></button>
<?php endif; ?>

                  </center>
                </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

          </table>
        </div>

        <?php endif; ?>
        <!-- /.card-body -->
      </div>
</div>
<?php /**PATH D:\ernasaricateringv3\resources\views/livewire/user-orders-component.blade.php ENDPATH**/ ?>