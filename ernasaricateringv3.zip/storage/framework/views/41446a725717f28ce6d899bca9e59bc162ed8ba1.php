
<?php $__env->startSection('title'); ?>
   Rekapan Penjualan Ernasari
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<meta name="_token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>

<div class="col-12 col-sm-12">
    <div class="card">
      <div class="card-header">
        <h5>Rekapan Penjualan</h5>
      </div>
      <div class="card-body">
       
        <div class="tab-content" id="custom-tabs-one-tabContent">
          <div class="tab-pane fade show active" id="custom-tabs-one-home" role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Tanggal Pesan</th>
                  <th>Menu</th>
                  <th>Jumlah Dipesan</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $orderitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($item->order->created_at   )->translatedFormat('d F Y')); ?></td>
                    <td><?php echo e($item->menu->nama_menu); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
          </div>
        </div>
      </div>
      <div class="card-footer">
        <a href="<?php echo e(route('pesanan.index')); ?>" class="btn btn-danger">Kembali</a>
      </div>
      <!-- /.card -->
    </div>
  </div>























































    

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $(function () {
        $.ajaxSetup({
            headers: { 'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content') }
        });
    });
    
    </script>
<script>

$('.tombol-hapus').on('click', function (e) {            

e.preventDefault();

const href =$(this).attr('href');

Swal.fire({
title: 'Apakah anda yakin ?',
text: "Transaksi pesanan ini akan dihapus",
type: 'warning',
showCancelButton: true,
confirmButtonColor: '#3085d6',
cancelButtonColor: '#d33',
confirmButtonText: 'Ya'
}).then((result) => {
if (result.value) {
    document.location.href = href;
    Swal.fire(
  'Terhapus!',
  'Data berhasil dihapus.',
  'success'
)
}
})

});

</script>

<script type="text/javascript">

    $('#search').on('click',function(){
        
    $tgl1=$("#tgl1").val();
    $tgl2=$("#tgl2").val();
    console.log($tgl1);
    $.ajax({
    
    type : 'get',
    
    url : '<?php echo e(url("laporan/search")); ?>',
    
    data:{'tgl1':$tgl1,'tgl2':$tgl2},
    
    success:function(data){
    
    $('tbody').html(data);
    
    }
    
    });
    
    
    
    })
    
    </script>
    
    
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/layout-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ernasaricateringv3\resources\views/backend/laporan/rekap-penjualan.blade.php ENDPATH**/ ?>