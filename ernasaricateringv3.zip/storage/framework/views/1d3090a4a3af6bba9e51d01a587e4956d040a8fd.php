<?php $__env->startSection('content'); ?>
<br>
    <section class="content">
        <div class="container-fluid">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Ubah Kategori Menu Makanan</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <form method="POST" name="FormTambah" onsubmit="return Validation()" enctype="multipart/form-data"
                action="<?php echo e(route('kategori.update', $kategori->id)); ?>">
                 <?php echo csrf_field(); ?>
                  <div class="card-body">
                    <div class="form-group">
                      <label for="kategori">Nama Kategori</label>
                      <input type="text" class="form-control" required value="<?php echo e($kategori->kategori); ?>" id="kategori" name="kategori" placeholder="Masukan Kategori menu makanan">
                    </div>
                    <div class="form-group">
                        <label for="slug">Slug</label>
                        <input type="text" class="form-control" required value="<?php echo e($kategori->slug); ?>" id="slug" name="slug" placeholder="Masukan slug menu makanan">
                      </div>


                  </div>
                  <!-- /.card-body -->

                  <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <a href="<?php echo e(route('menu.index')); ?>" class="btn btn-danger">Kembali</a>
                  </div>
                </form>
              </div>
              <!-- /.card -->

        </div><!-- /.container-fluid -->
      </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend/layout-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ernasaricateringv3\resources\views/backend/kategori/edit.blade.php ENDPATH**/ ?>