<div class="site-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
      <div class="row">
        <div class="col-md-6">
          <img src="<?php echo e(asset('storage/fotomenu/'. $menus->foto)); ?>" alt="Image" class="img-fluid">
        </div>
        <div class="col-md-6">
          <h2 class="text-black"><?php echo e($menus->nama_menu); ?></h2>
          
          <p><?php echo e($menus->deskripsi); ?></p>
          <?php if($menus->stock > 1): ?>
          <span class="badge text-bg-success"><i class="fa-solid fa-check"></i> Menu Tersedia</span>
          <?php else: ?>
          <span class="badge text-bg-danger"><i class="fa-solid fa-x"></i> Menu Habis</span>
          <?php endif; ?>
          

          <p><strong class="text-primary h4">Rp. <?php echo e(number_format($menus->harga,0,'.','.')); ?></strong></p>
          
          <div class="mb-5">

            <div class="input-group mb-3" style="max-width: 120px;">
                <p style="color: black"> Jumlah Pesanan</p>
            <input type="number" id="quantity" class="form-control text-center <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="quantity" max="<?php echo e($menus->stock); ?>">
          </div>

            <?php $__errorArgs = ['jumlah_pesanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
            </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <?php if($menus->stock > 1): ?>
          <p><button wire:click.prevent="store(<?php echo e($menus->id); ?>,'<?php echo e($menus->nama_menu); ?>',<?php echo e($menus->harga); ?>)" type="submit" class="btn btn-sm text-black" style="background-color: #d49701; :color : black" <?php if($menus->stock_status === 'outofstock'): ?> <?php if(true): echo 'disabled'; endif; ?> <?php endif; ?>>Tambahkan Ke Keranjang</button></p>
          <?php else: ?>

          <?php endif; ?>
        
        </div>
      </div>
    </div>
  </div>
<?php /**PATH D:\ernasaricateringv3\resources\views/livewire/menu-detail.blade.php ENDPATH**/ ?>