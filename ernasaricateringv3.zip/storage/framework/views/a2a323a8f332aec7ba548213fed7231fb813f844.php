<?php $__env->startSection('title'); ?>
    Detail Pesanan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5>Detail Pesanan</h5>
                </div>


          <!-- Main content -->
          <div class="invoice p-3 mb-3">
            <!-- info row -->
            <div class="row invoice-info">
                <table class="table table">
                      <tr>
                        <td width="20%">ID ORDER</td>
                        <td><?php echo e($pesananOr->id); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Nama Pelanggan</td>
                        <td><?php echo e($pesananOr->nama_lengkap); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Tanggal Pemesanan</td>
                        <td><?php echo e($pesananOr->created_at); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">No. Hp</td>
                        <td><?php echo e($pesananOr->nohp); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Alamat</td>
                        <td><?php echo e($pesananOr->alamat); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Metode Pembayaran</td>
                        <td><?php echo e($pesananOr->transaction->mode); ?></td>
                      </tr>

                      <tr>
                        <td width="20%">Catatan Pesanan</td>
                        <td><?php echo e($pesananOr->catatan); ?></td>
                      </tr>

                  </table>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- Table row -->
            <div class="row">
              <div class="col-12 table-responsive">
                <table class="table table-striped">
                  <thead>
                  <tr>
                    <th width="10%">Qty</th>
                    <th width="20%">Foto</th>
                    <th>Menu Makanan</th>
                    <th>Harga</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $pesananOr->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><img src="<?php echo e(asset('storage/fotomenu/'. $item->menu->foto)); ?>" width="50%" ></td>
                        <td><?php echo e($item->menu->nama_menu); ?></td>
                        <td>Rp. <?php echo e(number_format($item->price,0,'.','.')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>
                </table>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <div class="row">
              <!-- accepted payments column -->
              
              <!-- /.col -->
              
              <div class="col-12">
                <div class="table-responsive">
                  <table class="table">
                    <tr>
                      <th style="width:72%">Subtotal</th>
                      <td>Rp. <?php echo e(number_format((float)$pesananOr->subtotal,3,'.','.')); ?></td>
                    </tr>
                    <tr>
                      <th>Ongkir</th>
                      <td>Rp. 10.000</td>
                    </tr>
                    <tr>
                      <th>Total:</th>
                      <td><b> Rp. <?php echo e(number_format((float)$pesananOr->total,3,'.','.')); ?></b></td>
                    </tr>
                    <tr>
                        <?php if($pesananOr->status == 'dikirim'): ?>
                        <th>Tanggal kirim</th>
                        <td><b> <?php echo e($pesananOr->delivered_date); ?></b></td>
                        <?php elseif($pesananOr->status == 'cancel'): ?>
                        <th>Tanggal cancel</th>
                        <td><b> <?php echo e($pesananOr->canceled_date); ?></b></td>
                        <?php endif; ?>
                    </tr>
                  </table>
                </div>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- this row will not appear when printing -->
            <div class="row no-print">
              <div class="col-12">
                <form action="<?php echo e(route('pesanan.detail-print')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($pesananOr->id); ?>" name="id">
                <button type="submit" class="btn btn-default" rel="noopener" formtarget="_blank"><i class="fas fa-print"></i> Print</button>
                </form>
                

                

                


                <a href="<?php echo e(route('pesanan.index')); ?>" style="margin: 5px;" class="btn btn-warning float-right"><i class="far fa-back"></i> Kembali </a>
              </div>
            </div>
          </div>
        </div>
          <!-- /.invoice -->
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend/layout-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ernasaricateringv3\resources\views/backend/pesanan/detail.blade.php ENDPATH**/ ?>