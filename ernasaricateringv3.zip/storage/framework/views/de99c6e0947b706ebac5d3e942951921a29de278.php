<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ernasari Catering | Print Detail</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('')); ?>backend/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('')); ?>backend/dist/css/adminlte.min.css">
</head>
<body>
<div class="wrapper">
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <center>
                        <h5>Detail Pesanan</h5>
                    </center>
                </div>


          <!-- Main content -->
          <div class="invoice p-3 mb-3">
            <!-- info row -->
            <div class="row invoice-info">
                <table class="table table">
                    <tr>
                        <td width="20%">ID ORDER</td>
                        <td><?php echo e($pesanan->id); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Nama Pelanggan</td>
                        <td><?php echo e($pesanan->nama_lengkap); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Tanggal Pemesanan</td>
                        <td><?php echo e($pesanan->created_at); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">No. Hp</td>
                        <td><?php echo e($pesanan->nohp); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Alamat</td>
                        <td><?php echo e($pesanan->alamat); ?></td>
                      </tr>
                      <tr>
                        <td width="20%">Metode Pembayaran</td>
                        <td><?php echo e($pesanan->transaction->mode); ?></td>
                      </tr>

                  </table>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- Table row -->
            <div class="row">
              <div class="col-12 table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                          <th width="10%">Qty</th>
                          <th width="20%">Foto</th>
                          <th>Menu Makanan</th>
                          <th>Harga</th>
                        </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $pesanan->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($item->quantity); ?></td>
                              <td><img src="<?php echo e(asset('storage/fotomenu/'. $item->menu->foto)); ?>" width="50%" ></td>
                              <td><?php echo e($item->menu->nama_menu); ?></td>
                              <td>Rp. <?php echo e(number_format($item->price,0,'.','.')); ?></td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                </table>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <div class="row">
              <!-- accepted payments column -->
              
              <!-- /.col -->
              <div class="col-12">
                <div class="table-responsive">
                    <table class="table">
                      <tr>
                        <th style="width:72%">Subtotal</th>
                        <td>Rp. <?php echo e(number_format((float)$pesanan->subtotal,3,'.','.')); ?></td>
                      </tr>
                      <tr>
                        <th>Ongkir</th>
                        <td>Rp. 10.000</td>
                      </tr>
                      <tr>
                        <th>Total:</th>
                        <td><b> Rp. <?php echo e(number_format($pesanan->total,0,'.','.')); ?></b></td>
                      </tr>
                    </table>
                  </div>
                </div>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- this row will not appear when printing -->
            <div class="row no-print">
              <div class="col-12">
                <form action="<?php echo e(route('pesanan.detail-print')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($pesanan->id); ?>">
                <button type="submit" class="btn btn-default"><i class="fas fa-print"></i> Print</button>
                </form>
                
                <button type="button" class="btn btn-success float-right"><i class="far fa-credit-card"></i> Submit
                  Payment
                </button>
                <button type="button" class="btn btn-primary float-right" style="margin-right: 5px;">
                  <i class="fas fa-download"></i> Generate PDF
                </button>
              </div>
            </div>
          </div>
        </div>
          <!-- /.invoice -->
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- ./wrapper -->
<!-- Page specific script -->
<script>
  window.addEventListener("load", window.print());
</script>
</body>
</html>
<?php /**PATH D:\ernasaricateringv3\resources\views/backend/pesanan/detail-print.blade.php ENDPATH**/ ?>