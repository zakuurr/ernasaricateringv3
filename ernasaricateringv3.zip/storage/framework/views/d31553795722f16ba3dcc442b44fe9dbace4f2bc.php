<div>
    <div class="site-section">
        <div class="container">
          <div class="row mb-5">
            <div class="row">
                <div class="col-md-12">
                    <?php if(session()->has('msg')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('msg')); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>

          </div>
          <div class="row mb-5">
            <div class="row">
                <div class="col-md-12">
                    <div class="site-blocks-table">
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                              <th>No</th>
                              <th class="product-thumbnail">Tanggal Pesan</th>
                              <th class="product-name">Kode Pemesanan</th>
                              <th class="product-quantity">Pesanan</th>
                              <th class="product-total">Status</th>
                              <th class="product-total">Metode Pembayaran</th>
                              <th class="product-total">Total Harga</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                            $no = 1;
                            $total = 0;
                            ?>
                                <?php $__empty_1 = true; $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td>
                                      <?php echo e($pesanan->created_at); ?></td>
                                      <td>
                                        <?php echo e($pesanan->kode_pemesanan); ?></td>
                                        <td>
                                                <?php $pesanan_details = \App\Models\PesananDetail::where('pesanan_id',$pesanan->id)->get() ?>
                                                <?php $__currentLoopData = $pesanan_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <ul>
                                                    <li><img src="<?php echo e(asset('storage/fotomenu/'. $pesanan_detail->menu->foto)); ?>" alt="Image" class="img-fluid mt-3 p-3" width="100">
                                                        <?php echo e($pesanan_detail->menu->nama_menu); ?>

                                                        </li>
                                                    </ul>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>

                                           <?php if($pesanan->status == 1): ?>
                                           <span class="badge badge-danger"> Belum Bayar </span>
                                                <?php elseif($pesanan->status == 2): ?>
                                                <span class="badge badge-success"> Sudah Bayar </span>
                                                <?php elseif($pesanan->status == 3): ?>
                                                <span class="badge badge-warning"> Di Batalkan </span>
                                                <?php elseif($pesanan->status == 4): ?>
                                                <span class="badge badge-primary"> Di Proses </span>
                                                <?php elseif($pesanan->status == 5): ?>
                                                <span class="badge badge-info"> Di Antar </span>
                                                <?php elseif($pesanan->status == 6): ?>
                                                <span class="badge badge-success"> Selesai </span>
                                                <?php endif; ?>

                                                <?php if($pesanan->status == 1): ?>

                                                <button wire:click.prevent="cancelOrder" class="btn btn-warning btn-sm">Cancel Pesanan</button>
                                                <?php endif; ?>
                                            </td>
                                        <td>
                                            <?php echo e($pesanan->metode_p); ?></td>
                                        </td>
                                        <td>
                                           Rp. <?php echo e(number_format($pesanan->total_harga,0,'.','.')); ?>

                                         </td>

                                    </tr>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7">Data Kosong</td>
                                </tr>
                                <?php endif; ?>
                          </tbody>
                        </table>
                      </div>
                </div>
            </div>
          </div>

        </div>
      </div>
</div>
<?php /**PATH D:\ernasaricateringv3\resources\views/livewire/history.blade.php ENDPATH**/ ?>