<div>
    <main id="main" class="main-site">
		<div class="container pb-60">
			<div class="row">
				<div class="col-md-12 text-center">
					<h2>Terima Kasih</h2>
                    <p>Konfirmasi email telah dikirim.</p>
                    <a href="{{route('list-menu')}}" class="btn btn-checkout text-black" style="background-color: #d49701; :color : black">Lanjutkan Belanja</a>
				</div>
			</div>
		</div><!--end container-->

	</main>
</div>
